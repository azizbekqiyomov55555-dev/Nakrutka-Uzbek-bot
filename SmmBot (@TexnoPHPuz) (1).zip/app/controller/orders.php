<?php

require ('sql_connect.php');
include  ("../../index.php");
?>
	
	
  <!DOCTYPE html>
<html lang="uz"><head>
  <base href="https://<?=$_SERVER['HTTP_HOST']?>">
  
  
  <title>Buyurtmalar tarixi </title>
  <meta property="og:title" content="Buyurtmalar tarixi" />
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="keywords" content="Smm panel russian and uzbekistan,smm panel script,smm panel promotion,smm panel netflix,smm panel world,smm panel for free fire,smm panel premium accounts,smm panel app,smm panel apk,smm panel amazon prime,smm panel adalah,smm panel australia,smm panel america,smm panel accept paypal,smm panel api integration,the smm panel,create a smm panel,smm panel blue badge,smm panel bd,smm panel blackhatworld,smm panel bitcoin,smm panel boost,smm panel best price,smm panel business,smm panel bhw,best smm panel,smm panel club,smm panel creator,smm panel cheap india,smm panel.com,smm panel carding,smm panel comparison,total smm panel.com,smm panel service.com,c-dl.com smm panel,c-di.com smm panel,smm panel domain,smm panel discord,smm panel design,smm panel developer,smm panel drip feed,smm panel deutsch,smm panel data,smm panel script download free,original smm panel,smm panel ekşi,best smm panel ever,elite smm panel,easy smm panel,expert smm panel,ecommerce smm panel,enigma smm panel script,smm panel for carding,smm panel for youtube mo">
  <meta name="description" content=" has the Cheapest SMM Panel and 100% High Quality for all social networks. Get the best Instagram panel today">
  <meta property="og:description" content=" has the Cheapest SMM Panel and 100% High Quality for all social networks. Get the best Instagram panel today" />    <link rel="shortcut icon" type="image/ico" href="public/images/8df1bd5982b694d09ace0550ed9f0738fc91dc3e.png" />
 
  
      <link rel="stylesheet" type="text/css" href="https://<?=$_SERVER['HTTP_HOST']?>/public/<?=$theme?>/bootstrap.css">
      <link rel="stylesheet" type="text/css" href="https://<?=$_SERVER['HTTP_HOST']?>/public/<?=$theme?>/<?=$style?>.css">
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css"><center>


  </head>
 <style>


.main-panel .index-announcement {
    float: left;
    width: 100%;
    border-radius: 10px;
}
.main-panel .index-announcement .index-announcement-title {
    float: left;
    width: 100%;
    margin-top: 0;
    font-weight: 600;
    color: #000000;
    margin-bottom: 1px;
    background: #AA00FF;
    padding: 20px 30px;
    border-radius: 10px 10px 0 0;
}
.main-panel .index-announcement .index-announcement-bell {
    float: left;
    width: 50%;
    padding-right: 43px;
    text-align: right;
    margin-top: -20px;
    }
    
.main-panel .index-announcement .index-announcement-content {
    float: left;
    width: 100%;
    overflow-x: hidden;
    overflow-y: scroll;
    height: 470px;
    padding: 0 30px;
    background: #ffffff;
    border-radius: 0 0 10px 10px;
}
.main-panel .index-announcement ul {
    float: left;
    width: 100%;
    margin-top: 10px;
    margin-bottom: 0;
    border-left: 4px solid #eff0ff;
    padding-left: 30px;
}
.main-panel .index-announcement ul li {
    list-style: none;
    float: left;
    width: 100%;
    position: relative;
    margin-bottom: 45px;
    box-shadow: 1px 5px 19px 0 rgb(0 0 0 / 22%);
    padding: 20px;
    border-radius: 0 0 6px 6px;
}
.main-panel .index-announcement ul li:before {
    content: "";
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    height: 1px;
}
.main-panel .index-announcement ul li .icon {
    position: absolute;
    left: -52px;
    top: 48px;
    width: 40px;
    height: 40px;
    padding: 7px 0;
    text-align: center;
    background: #eff0ff;
    font-size: 16px;
    border-radius: 3px;
    box-shadow: 1px 5px 19px 0 rgba(255,255,255,0.05);
}
.main-panel .index-announcement ul li .time {
    float: left;
    color: #8c909a;
    border-radius: 3px;
    margin-top: 8px;
}
.main-panel .index-announcement ul li .time i {
    margin-right: 5px;
}
.main-panel .index-announcement ul li .t-instagram {
    color: #f40083;
    border-color: #f40083;
}
.main-panel .index-announcement ul li .service {
    float: left;
    width: 100%;
    color: #48494c;
    font-weight: 600;
    margin-top: 10px;
}
.main-panel .index-announcement ul li .desc {
    float: left;
    width: 100%;
    color: #8c909a;
    margin-top: 5px;
}
.main-panel .index-announcement ul li .title {
    float: right;
    color: #8c909a;
    padding: 5px 10px;
    border: 1px solid #8c909a;
    border-radius: 3px;
    width: 90px;
    text-align: center;
    position: relative;
}
.main-panel .index-announcement ul li .t-instagram {
    color: #f40083;
    border-color: #f40083;
}
.main-panel .index-announcement ul li .icon img {
    max-width: 60%;
}
.w .index-announcement-title {
    float: left;
    width: 100%;
    margin-top: 0px;
    font-weight: 600;
    color: #000000;
    margin-bottom: 12px;
    background: #ffffff;
    padding: 20px 30px;
    border-radius: 10px 10px 0 0;
    border-bottom: 1px solid #f33694;
}


</style>
<body class="body ">
<div class="wrapper  wrapper-sidebar-navbar ">
   <div id="block_82" class="component_private_navbar">
    <span class="component_private_navbar ">
      <div class="component-navbar-private__wrapper">
         <div class="sidebar-block__top component-navbar component-navbar__navbar-private editor__component-wrapper">
            <div>
               <nav class="navbar navbar-expand-lg navbar-light">
                      <div style="left:30px;" class="sidebar-block__top-brand">
                                                        <div class="component-navbar-brand component-navbar-public-brand">
                                                                  <a target="_self" href="/"><span style="text-transform: "><span style="font-size: 24px"><span style="letter-spacing: 1.0px"><span style="line-height: 120px"><strong style="font-weight: bold"><?=$_SERVER['HTTP_HOST']?></strong></span></span></span></span></a>
                                                              </div>
                                                                          </div>
                      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-collapse-14" aria-controls="navbar-collapse-14" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-burger">
                        <span class="navbar-burger-line"></span>
                    </span>
                  </button>
                  <div class="collapse navbar-collapse" id="navbar-collapse-14">
                     <div class="component-navbar-collapse-divider"></div>
                     <div class="d-flex component-navbar-collapse">
                        <ul class="navbar-nav navbar-nav-sidebar-menu">
<li class="nav-item component-navbar-nav-item component-navbar-private-nav-item">
<a class="component-navbar-nav-link  component-navbar-nav-link__navbar-private "     href="/services" >
                                                                                      <span class="component-navbar-nav-link-icon">
                                             <img src="https://<?=$_SERVER['HTTP_HOST']?>/public/icons/social.png" width=20 height=20>
                                           </span>Xizmatlar<br>
                                                                        </a>
                               </li>                   <li class="nav-item component-navbar-nav-item component-navbar-private-nav-item">
<a class="component-navbar-nav-link  component-navbar-nav-link__navbar-private "     href="/api" >
                                                                                      <span class="component-navbar-nav-link-icon">
                                             <img src="https://<?=$_SERVER['HTTP_HOST']?>/public/icons/api.png" width=20 height=20>
                                           </span>API<br>
                                                                        </a>
                               </li>                   <li class="nav-item component-navbar-nav-item component-navbar-private-nav-item">
<a class="component-navbar-nav-link  component-navbar-nav-link__navbar-private "     href="https://t.me/apiseen_bot" >
                                                                                      <span class="component-navbar-nav-link-icon">
                                             <img src="https://<?=$_SERVER['HTTP_HOST']?>/public/icons/bot.png" width=20 height=20>
                                           </span>Bot
                                                                        </a>
                               </li> 
							   

                                                           </ul>
														  

</nav>
						</div>
					</div>
				</div>
			</span>

    
</div> <style>
 .body .modal .modal-content {
    background: #fff;
    color: black;
}

.modal-header h5 {
    color: black;
}
.modal-footer a {
    color: #fff;
}
.modal-header{
 border-bottom: none;
}
.modal-footer{
 border-top: none;
}
 </style>    <div class="wrapper-content">
    <div class="wrapper-content__header">
          </div>
      <div id="block_93">
    <div class="new_order-block ">
        <div class="bg"></div>
        <div class="divider-top"></div>
        <div class="divider-bottom"></div>
        <div class="container">
            <div class="row new-order-form">
                <div class="col-lg-4 col-lg-8 col-lg-12">
                   <div class="component_form_group component_card component_radio_button">
                      <div class=" ">
 
</div>
    </div>
  </div></div></div></div></div> 
    <div class="wrapper-content__body">
      <!-- Main variables *content* -->
      <div id="block_99">
    <div class="orders-history ">
        <div class="bg"></div>
        <div class="divider-top"></div>
        <div class="divider-bottom"></div>
        <div class="container-fluid">
            <div class="row">
                <div class="col">
                    <div class="orders-history__margin-tab">
                        <div class="component_status_tabs">
                            <div class="">
      <ul class="nav nav-pills tab ">
	  
        <li class="nav-item" >
<a <?php if($route[0]=="orders" and empty($route[1])){ echo "class='nav-link active'";}?> class="nav-link" href="orders">Buyurtmalar tarixi</a></li>
        <li class="nav-item">
<a <?php if($route[0]=="orders" and $route[1]=="Pending"){ echo "class='nav-link active'";}?> class="nav-link" href="orders/Pending">Kutilmoqda</a></li>
        <li class="nav-item">
<a <?php if($route[0]=="orders" and $route[1]=="Inprogress"){ echo "class='nav-link active'";}?> class="nav-link" href="orders/Inprogress">Jarayonda</a></li>
        <li class="nav-item">
<a <?php if($route[0]=="orders" and $route[1]=="Completed"){ echo "class='nav-link active'";}?> class="nav-link" href="orders/Completed">Bajarildi</a></li>
        <li class="nav-item">
<a <?php if($route[0]=="orders" and $route[1]=="Partial"){ echo "class='nav-link active'";}?> class="nav-link" href="orders/Partial">Qisman</a></li>
        <li class="nav-item">
<a <?php if($route[0]=="orders" and $route[1]=="Processing"){ echo "class='nav-link active'";}?> class="nav-link" href="orders/Processing">Qayta ishlash</a></li>
        <li class="nav-item">
<a <?php if($route[0]=="orders" and $route[1]=="Canceled"){ echo "class='nav-link active'";}?> class="nav-link" href="orders/Canceled">Bekor qilingan</a></li>
       
      </ul><br>
	       <div class="row">
                <div class="col-12">
                    <div class="orders-history__margin-search component_card">
                        <div class="card">
                            <div class="component_form_group component_button_search">
                                <div class="">
                                    <form action="" method="get" id="history-search">
                                        <div class="input-group">
                                            <input type="text" name="search" class="form-control" value="" placeholder="Buyurtmani qidirish">
                                            <div class="input-group-append">
                                                <button class="btn btn-big-secondary" type="submit">
                                                    <span class="fas fa-search"></span>
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                             </div>
                        </div>
                    </div>
                </div>
            </div>
     <div class="row">
                <div class="col">
                    <div class="orders-history__margin-table">
                        <div class="table-bg component_table ">
                            <div class="table-wr table-responsive">
        <table class="table ">
          <thead>
            <tr>
              <th>ID</th>
              <th>Sana</th>
              <th>Buyurtmachi</th>
              <th>Narxi</th>
              <th>Xizmat nomi</th>
              <th>Holat</th>
              <th>Qoldiq</th>

            </tr>
          </thead>
          
          <?php 
          
         if($route[0]=="orders") {
          $key=$route[1];
          }elseif($route[0]=="orders" and $route[1]){
          $key = $route[2];
          }
          $b = mysqli_query($connect,"SELECT * FROM users WHERE api_key = '$key'");
$res = mysqli_fetch_assoc($b);

$id =$res['id'];

if($route[0]=="orders") {
          
          $sql = "SELECT * FROM myorder WHERE user_id = $id";
          }elseif($route[0]=="orders" and ($route[1]=="Completed")){
          
          $status = $route[1];
          echo $status;
        $sql = "SELECT * FROM myorder WHERE user_id = $id AND status = '$status'";
 }
         

$q = mysqli_query($connect,$sql);
while($d = mysqli_fetch_assoc($q)):
 echo $status;?>          
          
          <tbody>

<td>
<span id="order-<?=$d['order_id']?>"><?=$d['order_id']?></span>
                                        <a>
                                            <span
                                                data-clip="true"
                                                title="Order Id copied"
                                                data-clipboard-action="copy"
                                                data-clipboard-target="#order-<?=$d['order_id']?>"
                                                class="fas fa-clone"></span>
                                        </a><a class="btn btn-actions">Api</a> </td>
                <td><?=$d['order_create']?></td>
                <td><a class="btn btn-actions"><?=$d['user_id']?></a></td>
                <td><?=$d['retail']?></td>
                
                
                <td><a class="btn btn-actions">❤️ Instagram  Followers - [BOT - 5K][Free]</a></td>
               <?
               $status = $d['status'];
 if($status == "Completed") {
 $color = "green";
 }elseif($status == "In progress") {
 $color = "blue";
 }elseif($status == "Processing") {
 $color = "blue";
 }elseif($status == "Canceled") {
 $color = "red";
 }elseif($status == "Partial"){
 $color = "yellow";
 }?>
 <td><a class="btn btn-actions" style="background:<?=$color?>;"><?=$d['status']?></a></td>
                <td>0</td>

                 </td>
              

	
              


          </tbody>
          <? endwhile;?>
          
              
         
        </table>
      </div>
    </div>
      
  <script type="text/javascript" src="/public/global/ch3915babussofa4.js">
    
  </script>
  <script type="text/javascript" src="/public/global/cgtptn05b64bwcs4.js">
      </script>
  <script type="text/javascript" src="/public/global/xcz59lmywkfdgsp4.js">
      </script>
  <script type="text/javascript" src="/public/global/wnzsoolloslhfumj.js">
      </script>
      



 
   
   
   

  
</body>
</html>
                       